-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июл 14 2014 г., 14:15
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `freedom`
--

-- --------------------------------------------------------

--
-- Структура таблицы `guild_members`
--

CREATE TABLE IF NOT EXISTS `guild_members` (
  `id_member` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `class` int(11) NOT NULL,
  `race` int(11) NOT NULL,
  `gender` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `achievementPoints` int(11) NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `specName` varchar(255) NOT NULL,
  `specRole` varchar(50) NOT NULL,
  `rank` int(11) NOT NULL,
  PRIMARY KEY (`id_member`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=200 ;

--
-- Дамп данных таблицы `guild_members`
--

INSERT INTO `guild_members` (`id_member`, `name`, `class`, `race`, `gender`, `level`, `achievementPoints`, `thumbnail`, `specName`, `specRole`, `rank`) VALUES
(1, 'Идемпокурим', 11, 6, 0, 90, 15130, 'howling-fjord/62/32813886-avatar.jpg', 'Feral', 'DPS', 6),
(2, 'Мордафка', 3, 2, 0, 90, 7535, 'howling-fjord/13/33410317-avatar.jpg', 'Survival', 'DPS', 4),
(3, 'Подонаг', 1, 2, 0, 90, 11430, 'howling-fjord/112/33431152-avatar.jpg', 'Protection', 'TANK', 4),
(4, 'Олечка', 2, 10, 1, 90, 12765, 'howling-fjord/181/33457077-avatar.jpg', 'Holy', 'HEALING', 4),
(5, 'Рандомир', 7, 6, 0, 90, 11845, 'howling-fjord/84/33486420-avatar.jpg', 'Restoration', 'HEALING', 4),
(6, 'Мцыри', 6, 2, 1, 90, 7215, 'howling-fjord/77/33507405-avatar.jpg', 'Unholy', 'DPS', 7),
(7, 'Урмаа', 5, 26, 1, 90, 7215, 'howling-fjord/74/33525322-avatar.jpg', 'Shadow', 'DPS', 4),
(8, 'Шаггот', 5, 10, 0, 90, 15590, 'howling-fjord/69/33550661-avatar.jpg', 'Holy', 'HEALING', 1),
(9, 'Флинн', 8, 8, 0, 90, 12735, 'howling-fjord/34/36508706-avatar.jpg', 'Frost', 'DPS', 2),
(10, 'Хуманпаладин', 6, 10, 0, 90, 11690, 'howling-fjord/73/38895433-avatar.jpg', 'Frost', 'DPS', 8),
(11, 'Избушкагого', 7, 8, 1, 90, 8960, 'howling-fjord/181/39636149-avatar.jpg', 'Restoration', 'HEALING', 4),
(12, 'Антох', 6, 5, 0, 90, 8960, 'howling-fjord/211/39636435-avatar.jpg', 'Frost', 'DPS', 7),
(13, 'Турбодятел', 3, 8, 0, 90, 19265, 'howling-fjord/145/40270481-avatar.jpg', 'Survival', 'DPS', 4),
(14, 'Ивсит', 2, 10, 0, 90, 15590, 'howling-fjord/121/42220665-avatar.jpg', 'Retribution', 'DPS', 6),
(15, 'Гетайп', 6, 8, 1, 90, 14010, 'howling-fjord/227/42740451-avatar.jpg', 'Unholy', 'DPS', 4),
(16, 'Долбодятел', 6, 9, 0, 90, 19265, 'howling-fjord/170/47471018-avatar.jpg', 'Blood', 'TANK', 7),
(17, 'Топган', 3, 8, 0, 90, 6855, 'howling-fjord/53/52344629-avatar.jpg', 'Beast Mastery', 'DPS', 4),
(18, 'Бертран', 9, 9, 0, 90, 15590, 'howling-fjord/172/52516012-avatar.jpg', 'Destruction', 'DPS', 6),
(19, 'Зек', 9, 5, 0, 90, 15130, 'howling-fjord/57/53171257-avatar.jpg', 'Destruction', 'DPS', 0),
(20, 'Маеток', 1, 6, 0, 90, 15130, 'howling-fjord/90/53173082-avatar.jpg', 'Fury', 'DPS', 1),
(21, 'Ланкоми', 5, 10, 1, 90, 20715, 'howling-fjord/228/53180644-avatar.jpg', 'Shadow', 'DPS', 2),
(22, 'Лебик', 2, 10, 0, 90, 13530, 'howling-fjord/5/53314309-avatar.jpg', 'Retribution', 'DPS', 4),
(23, 'Вайлдсоул', 11, 8, 0, 87, 14985, 'howling-fjord/109/53515373-avatar.jpg', 'Guardian', 'TANK', 7),
(24, 'Пристишка', 5, 10, 1, 90, 15130, 'howling-fjord/203/53626827-avatar.jpg', 'Holy', 'HEALING', 6),
(25, 'Дайрект', 7, 2, 0, 90, 6805, 'howling-fjord/218/53852634-avatar.jpg', 'Restoration', 'HEALING', 7),
(26, 'Шурфдру', 11, 6, 0, 90, 19115, 'howling-fjord/27/54128155-avatar.jpg', 'Feral', 'DPS', 8),
(27, 'Шнипс', 3, 8, 0, 90, 7370, 'howling-fjord/168/54909352-avatar.jpg', 'Beast Mastery', 'DPS', 6),
(28, 'Пандиан', 6, 10, 1, 90, 19080, 'howling-fjord/161/55180449-avatar.jpg', 'Frost', 'DPS', 4),
(29, 'Простодятел', 7, 9, 0, 80, 19265, 'howling-fjord/232/55231464-avatar.jpg', 'Restoration', 'HEALING', 8),
(30, 'Фиснер', 9, 8, 0, 90, 14555, 'howling-fjord/54/55726390-avatar.jpg', 'Destruction', 'DPS', 2),
(31, 'Муркааня', 6, 6, 1, 67, 13220, 'howling-fjord/252/55896828-avatar.jpg', 'Blood', 'TANK', 8),
(32, 'Лобзикус', 3, 5, 0, 90, 4260, 'howling-fjord/83/56480339-avatar.jpg', 'Marksmanship', 'DPS', 6),
(33, 'Нкоми', 1, 26, 1, 90, 20715, 'howling-fjord/129/56524673-avatar.jpg', 'Fury', 'DPS', 7),
(34, 'Шивакарама', 9, 2, 1, 90, 7370, 'howling-fjord/207/56529615-avatar.jpg', 'Demonology', 'DPS', 6),
(35, 'Шарнира', 6, 10, 1, 66, 2600, 'howling-fjord/172/56972460-avatar.jpg', 'Blood', 'TANK', 7),
(36, 'Юбелка', 8, 5, 1, 90, 20715, 'howling-fjord/132/58103684-avatar.jpg', 'Frost', 'DPS', 7),
(37, 'Литвинов', 7, 9, 0, 90, 4260, 'howling-fjord/36/58346276-avatar.jpg', 'Elemental', 'DPS', 6),
(38, 'Свинчег', 11, 6, 0, 90, 6620, 'howling-fjord/40/60173096-avatar.jpg', 'Balance', 'DPS', 6),
(39, 'Кальнчик', 8, 2, 0, 80, 4260, 'howling-fjord/51/60591923-avatar.jpg', 'Fire', 'DPS', 6),
(40, 'Кроцея', 2, 10, 1, 90, 6070, 'howling-fjord/238/60892398-avatar.jpg', 'Protection', 'TANK', 4),
(41, 'Шпунтер', 3, 9, 0, 90, 11700, 'howling-fjord/1/61307649-avatar.jpg', 'Beast Mastery', 'DPS', 8),
(42, 'Виленна', 5, 8, 1, 90, 12655, 'howling-fjord/76/63668812-avatar.jpg', 'Shadow', 'DPS', 8),
(43, 'Малё', 7, 2, 1, 90, 20215, 'howling-fjord/142/63746446-avatar.jpg', 'Elemental', 'DPS', 2),
(44, 'Тибетка', 2, 10, 1, 90, 7370, 'howling-fjord/83/65499475-avatar.jpg', 'Retribution', 'DPS', 6),
(45, 'Зарквон', 7, 8, 0, 90, 15540, 'howling-fjord/221/65858781-avatar.jpg', 'Elemental', 'DPS', 7),
(46, 'Эльтрэвен', 3, 8, 0, 90, 18190, 'howling-fjord/55/66173751-avatar.jpg', 'Beast Mastery', 'DPS', 4),
(47, 'Гаутхильд', 9, 10, 1, 90, 18190, 'howling-fjord/10/66823178-avatar.jpg', 'Destruction', 'DPS', 7),
(48, 'Мырд', 8, 9, 0, 90, 7180, 'howling-fjord/122/67061114-avatar.jpg', 'Frost', 'DPS', 4),
(49, 'Мунамаф', 10, 26, 0, 90, 3255, 'howling-fjord/235/67505131-avatar.jpg', 'Windwalker', 'DPS', 4),
(50, 'Лямуррка', 5, 9, 1, 90, 14875, 'howling-fjord/232/67796712-avatar.jpg', 'Discipline', 'HEALING', 7),
(51, 'Бальмунк', 3, 2, 0, 90, 16545, 'howling-fjord/110/68270702-avatar.jpg', 'Survival', 'DPS', 2),
(52, 'Алем', 11, 8, 0, 69, 14220, 'howling-fjord/46/68593198-avatar.jpg', 'Guardian', 'TANK', 8),
(53, 'Зигус', 10, 26, 0, 90, 7370, 'howling-fjord/171/68808363-avatar.jpg', 'Windwalker', 'DPS', 6),
(54, 'Рю', 10, 8, 1, 90, 20715, 'howling-fjord/149/68904341-avatar.jpg', 'Mistweaver', 'HEALING', 7),
(55, 'Зэнзэн', 10, 26, 1, 56, 11905, 'howling-fjord/17/70153489-avatar.jpg', 'Mistweaver', 'HEALING', 8),
(56, 'Пикселёк', 8, 9, 1, 90, 21500, 'howling-fjord/101/70201701-avatar.jpg', 'Frost', 'DPS', 1),
(57, 'Закур', 1, 2, 0, 90, 19030, 'howling-fjord/195/70642371-avatar.jpg', 'Arms', 'DPS', 2),
(58, 'Хэлфиш', 5, 10, 1, 90, 13775, 'howling-fjord/111/70664815-avatar.jpg', 'Discipline', 'HEALING', 4),
(59, 'Энзи', 11, 8, 0, 90, 19030, 'howling-fjord/102/70841446-avatar.jpg', 'Restoration', 'HEALING', 7),
(60, 'Жанщи', 1, 26, 1, 90, 13775, 'howling-fjord/62/71288894-avatar.jpg', 'Arms', 'DPS', 7),
(61, 'Кирани', 2, 10, 1, 90, 19810, 'howling-fjord/121/71352441-avatar.jpg', 'Retribution', 'DPS', 7),
(62, 'Нэверморе', 9, 5, 0, 87, 19810, 'howling-fjord/235/71425003-avatar.jpg', 'Destruction', 'DPS', 7),
(63, 'Кэндарат', 11, 6, 1, 90, 19685, 'howling-fjord/92/71878748-avatar.jpg', 'Guardian', 'TANK', 7),
(64, 'Кескусе', 7, 9, 0, 90, 16030, 'howling-fjord/91/72173147-avatar.jpg', 'Restoration', 'HEALING', 4),
(65, 'Алдора', 6, 10, 1, 80, 19810, 'howling-fjord/28/72702236-avatar.jpg', 'Blood', 'TANK', 7),
(66, 'Зарублюха', 1, 2, 0, 90, 13595, 'howling-fjord/196/73027524-avatar.jpg', 'Arms', 'DPS', 4),
(67, 'Палаландос', 2, 6, 0, 90, 20625, 'howling-fjord/228/73039076-avatar.jpg', 'Protection', 'TANK', 7),
(68, 'Грэгхэк', 3, 2, 0, 90, 16425, 'howling-fjord/253/73141501-avatar.jpg', 'Beast Mastery', 'DPS', 4),
(69, 'Оптилон', 2, 6, 0, 90, 13790, 'howling-fjord/57/73250105-avatar.jpg', 'Retribution', 'DPS', 4),
(70, 'Свиттуф', 4, 5, 0, 90, 20625, 'howling-fjord/223/73260767-avatar.jpg', 'Assassination', 'DPS', 4),
(71, 'Люсти', 4, 10, 1, 90, 13460, 'howling-fjord/216/73277656-avatar.jpg', 'Combat', 'DPS', 2),
(72, 'Девилх', 10, 26, 0, 90, 10605, 'howling-fjord/80/73548880-avatar.jpg', 'Mistweaver', 'HEALING', 4),
(73, 'Касемыч', 5, 8, 0, 90, 14915, 'howling-fjord/4/73610500-avatar.jpg', 'Shadow', 'DPS', 4),
(74, 'Акропович', 8, 8, 0, 90, 10120, 'howling-fjord/21/73697045-avatar.jpg', 'Fire', 'DPS', 4),
(75, 'Аймаэстро', 2, 6, 0, 90, 18130, 'howling-fjord/162/73762978-avatar.jpg', 'Retribution', 'DPS', 4),
(76, 'Аръей', 4, 26, 0, 90, 18070, 'howling-fjord/242/73792242-avatar.jpg', 'Combat', 'DPS', 1),
(77, 'Элверин', 3, 10, 1, 90, 17610, 'howling-fjord/199/73951943-avatar.jpg', 'Survival', 'DPS', 2),
(78, 'Пиксельлок', 9, 9, 1, 90, 21500, 'howling-fjord/104/74050664-avatar.jpg', 'Destruction', 'DPS', 6),
(79, 'Мишкамонашка', 10, 26, 1, 90, 8030, 'howling-fjord/209/74171601-avatar.jpg', 'Windwalker', 'DPS', 4),
(80, 'Франклин', 9, 8, 1, 90, 18340, 'howling-fjord/18/74201362-avatar.jpg', 'Affliction', 'DPS', 2),
(81, 'Дизраэль', 4, 10, 1, 90, 17610, 'howling-fjord/51/74324019-avatar.jpg', 'Combat', 'DPS', 7),
(82, 'Шезгалор', 2, 10, 0, 90, 7180, 'howling-fjord/78/74612302-avatar.jpg', 'Holy', 'HEALING', 7),
(83, 'Вирсерж', 6, 2, 0, 90, 11145, 'howling-fjord/63/74759487-avatar.jpg', 'Frost', 'DPS', 4),
(84, 'Касемкин', 11, 8, 0, 90, 14915, 'howling-fjord/106/74958698-avatar.jpg', 'Balance', 'DPS', 8),
(85, 'Мурочкаа', 6, 10, 1, 90, 9445, 'howling-fjord/60/75092028-avatar.jpg', 'Frost', 'DPS', 8),
(86, 'Карпуха', 7, 9, 0, 90, 9980, 'howling-fjord/4/75168516-avatar.jpg', 'Elemental', 'DPS', 4),
(87, 'Урсулана', 5, 10, 1, 90, 19425, 'howling-fjord/69/75495493-avatar.jpg', 'Discipline', 'HEALING', 4),
(88, 'Кэмиронн', 10, 26, 0, 85, 20610, 'howling-fjord/51/75556147-avatar.jpg', 'Windwalker', 'DPS', 7),
(89, 'Подмогыч', 10, 2, 0, 90, 11185, 'howling-fjord/22/75586838-avatar.jpg', 'Mistweaver', 'HEALING', 7),
(90, 'Рейсер', 7, 2, 0, 90, 15810, 'howling-fjord/106/75598954-avatar.jpg', 'Restoration', 'HEALING', 7),
(91, 'Топферал', 11, 8, 0, 90, 18745, 'howling-fjord/110/75693934-avatar.jpg', 'Feral', 'DPS', 2),
(92, 'Болроуг', 6, 2, 0, 90, 17345, 'howling-fjord/199/75830983-avatar.jpg', 'Frost', 'DPS', 2),
(93, 'Водочкина', 11, 8, 1, 90, 1585, 'howling-fjord/238/75840750-avatar.jpg', 'Feral', 'DPS', 6),
(94, 'Хронеес', 2, 6, 0, 90, 14510, 'howling-fjord/182/76082102-avatar.jpg', 'Holy', 'HEALING', 2),
(95, 'Шионсан', 10, 26, 1, 90, 19810, 'howling-fjord/68/76101444-avatar.jpg', 'Windwalker', 'DPS', 7),
(96, 'Дресировщег', 3, 5, 0, 90, 17335, 'howling-fjord/123/76209275-avatar.jpg', 'Survival', 'DPS', 7),
(97, 'Резуррект', 5, 5, 0, 90, 18745, 'howling-fjord/250/76403962-avatar.jpg', 'Shadow', 'DPS', 7),
(98, 'Хэнша', 10, 26, 0, 90, 18745, 'howling-fjord/10/76403978-avatar.jpg', 'Windwalker', 'DPS', 7),
(99, 'Коровабобра', 2, 6, 0, 82, 11090, 'howling-fjord/76/76441164-avatar.jpg', 'Protection', 'TANK', 8),
(100, 'Тирнаель', 1, 5, 0, 90, 19810, 'howling-fjord/92/76461660-avatar.jpg', 'Protection', 'TANK', 7),
(101, 'Анш', 10, 26, 1, 90, 19850, 'howling-fjord/252/76498940-avatar.jpg', 'Brewmaster', 'TANK', 2),
(102, 'Лямурко', 6, 2, 1, 90, 15075, 'howling-fjord/222/76536798-avatar.jpg', 'Frost', 'DPS', 2),
(103, 'Волхвал', 7, 2, 0, 90, 20265, 'howling-fjord/4/76553476-avatar.jpg', 'Enhancement', 'DPS', 2),
(104, 'Бладисмайл', 9, 5, 1, 90, 13355, 'howling-fjord/21/76643349-avatar.jpg', 'Destruction', 'DPS', 7),
(105, 'Чинарь', 3, 2, 0, 90, 6805, 'howling-fjord/11/76839691-avatar.jpg', 'Beast Mastery', 'DPS', 7),
(106, 'Аэерайн', 5, 5, 1, 90, 19810, 'howling-fjord/222/76926430-avatar.jpg', 'Discipline', 'HEALING', 7),
(107, 'Заварка', 5, 8, 1, 90, 18755, 'howling-fjord/218/77171162-avatar.jpg', 'Discipline', 'HEALING', 2),
(108, 'Шашлычинка', 2, 6, 1, 51, 13485, 'howling-fjord/58/77460282-avatar.jpg', 'Holy', 'HEALING', 7),
(109, 'Келптар', 11, 6, 0, 90, 18745, 'howling-fjord/182/77469366-avatar.jpg', 'Balance', 'DPS', 7),
(110, 'Дурдулька', 11, 8, 0, 90, 4260, 'howling-fjord/36/77566244-avatar.jpg', 'Restoration', 'HEALING', 4),
(111, 'Мегадруля', 11, 6, 0, 90, 5720, 'howling-fjord/27/77634587-avatar.jpg', 'Guardian', 'TANK', 4),
(112, 'Федькович', 7, 9, 0, 33, 120, 'howling-fjord/127/77709183-avatar.jpg', 'Restoration', 'HEALING', 8),
(113, 'Энорабия', 9, 5, 1, 90, 18755, 'howling-fjord/193/78240193-avatar.jpg', 'Destruction', 'DPS', 7),
(114, 'Лионарт', 7, 6, 0, 90, 10865, 'howling-fjord/207/78297295-avatar.jpg', 'Enhancement', 'DPS', 7),
(115, 'Лионардо', 6, 6, 0, 90, 10865, 'howling-fjord/61/78297405-avatar.jpg', 'Frost', 'DPS', 2),
(116, 'Момотян', 5, 10, 1, 90, 6105, 'howling-fjord/52/78403892-avatar.jpg', 'Shadow', 'DPS', 2),
(117, 'Метредель', 4, 9, 1, 90, 18170, 'howling-fjord/76/78453836-avatar.jpg', 'Subtlety', 'DPS', 7),
(118, 'Авагадро', 7, 26, 1, 90, 18755, 'howling-fjord/94/78611038-avatar.jpg', 'Elemental', 'DPS', 7),
(119, 'Арила', 5, 26, 1, 90, 14510, 'howling-fjord/206/78662094-avatar.jpg', 'Discipline', 'HEALING', 7),
(120, 'Релди', 3, 2, 1, 90, 7850, 'howling-fjord/123/78761083-avatar.jpg', 'Beast Mastery', 'DPS', 1),
(121, 'Ундимиэль', 8, 10, 1, 90, 20400, 'howling-fjord/242/78762994-avatar.jpg', 'Frost', 'DPS', 2),
(122, 'Релдивар', 1, 2, 0, 90, 7850, 'howling-fjord/133/78923653-avatar.jpg', 'Fury', 'DPS', 7),
(123, 'Аймонэстро', 10, 26, 0, 30, 18130, 'howling-fjord/29/79023133-avatar.jpg', 'Windwalker', 'DPS', 7),
(124, 'Енотистая', 11, 8, 1, 90, 13675, 'howling-fjord/89/79052121-avatar.jpg', 'Guardian', 'TANK', 4),
(125, 'Даргош', 7, 2, 0, 90, 2205, 'howling-fjord/248/79162872-avatar.jpg', 'Enhancement', 'DPS', 4),
(126, 'Малёз', 1, 2, 0, 90, 20215, 'howling-fjord/179/79209907-avatar.jpg', 'Arms', 'DPS', 7),
(127, 'Низария', 11, 8, 1, 87, 15300, 'howling-fjord/163/79253667-avatar.jpg', 'Restoration', 'HEALING', 7),
(128, 'Киттен', 7, 26, 1, 44, 15300, 'howling-fjord/232/79483624-avatar.jpg', 'Restoration', 'HEALING', 7),
(129, 'Добродятел', 1, 2, 0, 81, 19265, 'howling-fjord/45/79528493-avatar.jpg', 'Protection', 'TANK', 8),
(130, 'Абеттор', 8, 8, 0, 90, 11515, 'howling-fjord/121/79551353-avatar.jpg', 'Arcane', 'DPS', 4),
(131, 'Датакульт', 11, 6, 0, 90, 8475, 'howling-fjord/23/79581207-avatar.jpg', 'Balance', 'DPS', 2),
(132, 'Тошу', 3, 8, 1, 90, 20400, 'howling-fjord/211/79595987-avatar.jpg', 'Beast Mastery', 'DPS', 7),
(133, 'Уркрафт', 3, 2, 0, 90, 18745, 'howling-fjord/165/79672485-avatar.jpg', 'Survival', 'DPS', 7),
(134, 'Девилзз', 9, 9, 0, 60, 10465, 'howling-fjord/12/79780876-avatar.jpg', 'Destruction', 'DPS', 7),
(135, 'Шеена', 2, 6, 1, 90, 20400, 'howling-fjord/175/79951791-avatar.jpg', 'Protection', 'TANK', 7),
(136, 'Мирла', 4, 5, 1, 90, 18745, 'howling-fjord/166/80019366-avatar.jpg', 'Assassination', 'DPS', 7),
(137, 'Бонпо', 7, 9, 0, 90, 7370, 'howling-fjord/60/80665404-avatar.jpg', 'Enhancement', 'DPS', 6),
(138, 'Неоринаменя', 2, 10, 1, 90, 14615, 'howling-fjord/148/80685716-avatar.jpg', 'Holy', 'HEALING', 4),
(139, 'Назжатар', 6, 2, 0, 90, 18745, 'howling-fjord/194/80750530-avatar.jpg', 'Frost', 'DPS', 7),
(140, 'Сварщег', 8, 8, 0, 90, 16365, 'howling-fjord/163/80755619-avatar.jpg', 'Frost', 'DPS', 8),
(141, 'Анастазия', 6, 2, 1, 90, 20645, 'howling-fjord/248/81213688-avatar.jpg', 'Frost', 'DPS', 8),
(142, 'Давина', 2, 10, 1, 30, 18615, 'howling-fjord/121/81999993-avatar.jpg', 'Protection', 'TANK', 7),
(143, 'Анадонесса', 5, 10, 1, 90, 1140, 'howling-fjord/134/82070406-avatar.jpg', 'Shadow', 'DPS', 4),
(144, 'Дэсэни', 5, 9, 0, 90, 7370, 'howling-fjord/196/82138820-avatar.jpg', 'Shadow', 'DPS', 6),
(145, 'Куннфу', 3, 26, 1, 30, 1130, 'howling-fjord/117/82150517-avatar.jpg', 'Marksmanship', 'DPS', 7),
(146, 'Локаторс', 9, 5, 0, 12, 4585, 'howling-fjord/173/83030445-avatar.jpg', 'Demonology', 'DPS', 8),
(147, 'Дансермен', 11, 6, 0, 90, 15180, 'howling-fjord/17/83860497-avatar.jpg', 'Restoration', 'HEALING', 4),
(148, 'Монреалль', 11, 6, 1, 90, 20215, 'howling-fjord/11/85408011-avatar.jpg', 'Balance', 'DPS', 7),
(149, 'Биммер', 9, 5, 0, 90, 12845, 'howling-fjord/149/85962133-avatar.jpg', 'Destruction', 'DPS', 4),
(150, 'Иштарус', 1, 6, 0, 90, 12300, 'howling-fjord/29/86020381-avatar.jpg', 'Protection', 'TANK', 8),
(151, 'Ариошка', 1, 2, 1, 90, 16500, 'howling-fjord/144/86026128-avatar.jpg', 'Fury', 'DPS', 2),
(152, 'Раська', 11, 8, 1, 90, 15810, 'howling-fjord/42/86132010-avatar.jpg', 'Feral', 'DPS', 4),
(153, 'Джелана', 7, 8, 1, 65, 1120, 'howling-fjord/149/86724501-avatar.jpg', 'Restoration', 'HEALING', 7),
(154, 'Убьютотемом', 7, 8, 0, 90, 15425, 'howling-fjord/51/86788403-avatar.jpg', 'Elemental', 'DPS', 7),
(155, 'Джангальбу', 4, 5, 0, 64, 3930, 'howling-fjord/55/86888247-avatar.jpg', 'Subtlety', 'DPS', 4),
(156, 'Аллигаттор', 10, 2, 0, 31, 20265, 'howling-fjord/52/86929972-avatar.jpg', 'Windwalker', 'DPS', 7),
(157, 'Гласорды', 7, 8, 0, 90, 1600, 'howling-fjord/248/87103992-avatar.jpg', 'Elemental', 'DPS', 6),
(158, 'Салабончик', 8, 8, 0, 90, 2460, 'howling-fjord/234/87107306-avatar.jpg', 'Frost', 'DPS', 4),
(159, 'Сантрайдер', 2, 6, 0, 90, 10225, 'howling-fjord/109/87346797-avatar.jpg', 'Holy', 'HEALING', 4),
(160, 'Тёмныйгеймер', 5, 5, 0, 90, 1600, 'howling-fjord/9/87347977-avatar.jpg', 'Holy', 'HEALING', 6),
(161, 'Априориа', 5, 5, 1, 90, 13355, 'howling-fjord/218/87387610-avatar.jpg', 'Holy', 'HEALING', 8),
(162, 'Вундервунван', 9, 5, 0, 85, 17025, 'howling-fjord/237/87391213-avatar.jpg', 'Destruction', 'DPS', 8),
(163, 'Илюшкашторм', 8, 5, 0, 90, 20215, 'howling-fjord/85/87428181-avatar.jpg', 'Frost', 'DPS', 7),
(164, 'Асгин', 9, 2, 0, 90, 19725, 'howling-fjord/222/87533278-avatar.jpg', 'Destruction', 'DPS', 2),
(165, 'Дикийпух', 9, 5, 0, 90, 1575, 'howling-fjord/17/87570193-avatar.jpg', 'Destruction', 'DPS', 4),
(166, 'Тассер', 1, 5, 0, 90, 18070, 'howling-fjord/111/87626607-avatar.jpg', 'Protection', 'TANK', 7),
(167, 'Верхушка', 11, 6, 0, 90, 620, 'howling-fjord/71/87857991-avatar.jpg', 'Feral', 'DPS', 7),
(168, 'Пиксельнеок', 9, 2, 1, 90, 20625, 'howling-fjord/30/87885598-avatar.jpg', 'Destruction', 'DPS', 7),
(169, 'Мозгофф', 9, 5, 0, 90, 945, 'howling-fjord/51/89025587-avatar.jpg', 'Destruction', 'DPS', 6),
(170, 'Матума', 3, 8, 0, 90, 1005, 'howling-fjord/226/89025762-avatar.jpg', 'Beast Mastery', 'DPS', 6),
(171, 'Энджина', 7, 8, 1, 90, 1155, 'howling-fjord/124/89026940-avatar.jpg', 'Enhancement', 'DPS', 6),
(172, 'Илиорис', 5, 10, 1, 90, 995, 'howling-fjord/122/89027194-avatar.jpg', 'Discipline', 'HEALING', 6),
(173, 'Волума', 2, 10, 1, 56, 18870, 'howling-fjord/204/89050060-avatar.jpg', 'Protection', 'TANK', 8),
(174, 'Виртис', 2, 10, 0, 55, 14855, 'howling-fjord/178/89150386-avatar.jpg', 'Holy', 'HEALING', 8),
(175, 'Реоран', 11, 6, 1, 90, 17610, 'howling-fjord/140/89317004-avatar.jpg', 'Restoration', 'HEALING', 4),
(176, 'Кискка', 8, 10, 1, 90, 15425, 'howling-fjord/224/90187488-avatar.jpg', 'Frost', 'DPS', 8),
(177, 'Нимвэ', 9, 10, 1, 90, 6105, 'howling-fjord/185/90221497-avatar.jpg', 'Destruction', 'DPS', 7),
(178, 'Йоксель', 6, 2, 0, 90, 1235, 'howling-fjord/69/90232645-avatar.jpg', 'Blood', 'TANK', 6),
(179, 'Инстигатор', 1, 6, 0, 90, 11515, 'howling-fjord/147/90437523-avatar.jpg', 'Protection', 'TANK', 4),
(180, 'Ромуланка', 7, 8, 1, 90, 1020, 'howling-fjord/223/90457055-avatar.jpg', 'Elemental', 'DPS', 6),
(181, 'Гераклидка', 11, 8, 1, 90, 1145, 'howling-fjord/20/90457108-avatar.jpg', 'Feral', 'DPS', 6),
(182, 'Сильтенка', 1, 8, 1, 90, 1020, 'howling-fjord/254/90473214-avatar.jpg', 'Arms', 'DPS', 8),
(183, 'Геркулеска', 4, 8, 1, 90, 1125, 'howling-fjord/81/90473297-avatar.jpg', 'Combat', 'DPS', 8),
(184, 'Апполонко', 3, 8, 1, 90, 1020, 'howling-fjord/142/90473358-avatar.jpg', 'Beast Mastery', 'DPS', 8),
(185, 'Поллитро', 4, 2, 0, 62, 980, 'howling-fjord/128/90526592-avatar.jpg', 'Combat', 'DPS', 8),
(186, 'Хунтерстайл', 3, 2, 0, 62, 1050, 'howling-fjord/121/90537849-avatar.jpg', 'Beast Mastery', 'DPS', 8),
(187, 'Алкогол', 5, 5, 0, 85, 1680, 'howling-fjord/32/90540576-avatar.jpg', 'Discipline', 'HEALING', 8),
(188, 'Балдас', 1, 5, 0, 61, 390, 'howling-fjord/180/90540724-avatar.jpg', 'Protection', 'TANK', 8),
(189, 'Вальтерка', 7, 2, 0, 62, 1165, 'howling-fjord/115/90540915-avatar.jpg', 'Elemental', 'DPS', 6),
(190, 'Чсвзашкалило', 4, 5, 0, 14, 8280, 'howling-fjord/160/90544544-avatar.jpg', 'Assassination', 'DPS', 8),
(191, 'Виктортретий', 6, 5, 0, 90, 1050, 'howling-fjord/254/90558718-avatar.jpg', 'Unholy', 'DPS', 6),
(192, 'Лёнякосмос', 11, 8, 0, 90, 1930, 'howling-fjord/151/90584983-avatar.jpg', 'Feral', 'DPS', 6),
(193, 'Мадеус', 5, 10, 1, 90, 17810, 'howling-fjord/152/90589592-avatar.jpg', 'Shadow', 'DPS', 8),
(194, 'Жёваныйкрот', 11, 8, 0, 21, 5425, 'howling-fjord/45/91539757-avatar.jpg', 'Restoration', 'HEALING', 8),
(195, 'Радогадка', 6, 2, 1, 90, 17825, 'howling-fjord/186/91595194-avatar.jpg', 'Blood', 'TANK', 4),
(196, 'Элаза', 5, 10, 1, 90, 20400, 'howling-fjord/237/91645165-avatar.jpg', 'Discipline', 'HEALING', 8),
(197, 'Девилхз', 6, 6, 0, 58, 10605, 'howling-fjord/167/91704487-avatar.jpg', 'Frost', 'DPS', 8),
(198, 'Релдишама', 7, 26, 1, 50, 7850, 'howling-fjord/40/91708712-avatar.jpg', 'Elemental', 'DPS', 6),
(199, 'Севенс', 11, 8, 0, 90, 8785, 'howling-fjord/98/91747682-avatar.jpg', 'Restoration', 'HEALING', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `news_name` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` mediumtext,
  `full_text` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `news_name`, `date`, `description`, `full_text`) VALUES
(6, 'ПРОДАЖА ОО25 ХМ + лут в подарок', '2001-04-20 11:00:00', 'Без передачи акка, можете умереть на пуле или поучаствовать в убийстве босса.\r\n\r\n<p>пакет на 12ХМ - 700кг<br/> \r\nпакет на 8ХМ - 300кг </p>\r\n\r\n<p>\r\nубийство 1 босса в ХМ (1-8 боссы) - 50кг<br/>\r\nубийство 1 босса в ХМ (9,10 боссы) - 100кг<br/>\r\nубийство 1 босса в ХМ (11-12 боссы) - 150кг<br/>\r\nубийство Гароша нормал - 50кг\r\n</p>\r\n\r\n<p>По всем вопросам обращайтесь тут либо в игре на Arey#2253, скайп arey_travian.</p>\r\n\r\n<p>* лут идущий в подарок - любые токены на ваш класс + весь героический 566 шмот + частично 572 шмот не нужный основному рейду, более подробно можете уточнить в игрес\r\n* при покупке пакета 12ХМ , вы получаете дисконт на второй заход 10% (скидка действует только на пакеты 8ХМ и 12ХМ)<br/>\r\n* на пакеты 8ХМ и 12 ХМ с передачей акка возможна скидка 10%</p>', 'Без передачи акка, можете умереть на пуле или поучаствовать в убийстве босса.\r\n\r\n<p>пакет на 12ХМ - 700кг<br/> \r\nпакет на 8ХМ - 300кг </p>\r\n\r\n<p>\r\nубийство 1 босса в ХМ (1-8 боссы) - 50кг<br/>\r\nубийство 1 босса в ХМ (9,10 боссы) - 100кг<br/>\r\nубийство 1 босса в ХМ (11-12 боссы) - 150кг<br/>\r\nубийство Гароша нормал - 50кг\r\n</p>\r\n\r\n<p>По всем вопросам обращайтесь тут либо в игре на Arey#2253, скайп arey_travian.</p>\r\n\r\n<p>* лут идущий в подарок - любые токены на ваш класс + весь героический 566 шмот + частично 572 шмот не нужный основному рейду, более подробно можете уточнить в игрес\r\n* при покупке пакета 12ХМ , вы получаете дисконт на второй заход 10% (скидка действует только на пакеты 8ХМ и 12ХМ)<br/>\r\n* на пакеты 8ХМ и 12 ХМ с передачей акка возможна скидка 10%</p>'),
(7, 'Freedom vs Garrosh Hellscream 25HM', '2001-04-20 11:00:00', '<iframe width="560" height="315" src="//www.youtube.com/embed/veZxmfNT6a8" frameborder="0" allowfullscreen></iframe>			', '<iframe width="560" height="315" src="//www.youtube.com/embed/veZxmfNT6a8" frameborder="0" allowfullscreen></iframe>			');

-- --------------------------------------------------------

--
-- Структура таблицы `structure`
--

CREATE TABLE IF NOT EXISTS `structure` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `structure`
--

INSERT INTO `structure` (`id`, `name`, `date`, `type`) VALUES
(1, 'Главная', '0000-00-00', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
